# Páginas clave (targets)

## /mentorias/
**Rol:** Hub comercial para agrupar mentorías y distribuir autoridad hacia productos.  
**Objetivo:** rankear por “mentoría para empresas de limpieza en USA” y variantes.

## /producto/organizacion-y-automatizacion-con-jobber/
**Rol:** Página BOFU para “Jobber en español” + automatización.  
**SKU:** Jobber  
**Imagen:** https://ngsolutions.training/wp-content/uploads/2025/10/Portadas-para-el-sitio-web-26.png

## /producto/transforma-tu-empresa-de-limpieza.../
**Rol:** Oferta premium 3–6 meses (marca + marketing + ventas + automatización).  
**SKU:** Mentoria Empresarial  
**Imagen:** https://ngsolutions.training/wp-content/uploads/2025/10/Portadas-para-el-sitio-web-20.png  
**Conversiones:** formulario + compra + Skool
